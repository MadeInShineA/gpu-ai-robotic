#include <iostream>

#include "CudaContextSimple.h"
#include "Limits.h"

using std::cerr;
using std::cout;
using std::endl;

// --------------------------------------------------------------------------------------
// Extern
// --------------------------------------------------------------------------------------

extern int mainCore(const Args &args);

// --------------------------------------------------------------------------------------
// Implementations
// --------------------------------------------------------------------------------------

int main(int argc, char **argv)
    {
    // Limits::show();

    CudaContextSimple cudaContext;

        // public
        {
        cudaContext.deviceId = 0; //  in [0,2] width Server Cuda3

        cudaContext.deviceDriver = DeviceDriver::LOAD_CURRENT; // LOAD_CURRENT   LOAD_ALL
        cudaContext.deviceInfo = DeviceInfo::ALL_SIMPLE;       // NONE  ALL  ALL_SIMPLE  CURRENT
        }

        // private
        {
        cudaContext.args.argc = argc;
        cudaContext.args.argv = argv;

        cudaContext.mainCore = mainCore;
        }

    return cudaContext.process();
    }

// --------------------------------------------------------------------------------------
// End
// --------------------------------------------------------------------------------------
