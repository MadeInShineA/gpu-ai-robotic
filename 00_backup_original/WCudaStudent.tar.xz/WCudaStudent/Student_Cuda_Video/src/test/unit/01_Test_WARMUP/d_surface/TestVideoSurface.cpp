#include "TestVideoSurface.h"

#include "VideoSurfaceProvider.h"

#include <assert.h>
#include <iostream>

using std::cerr;
using std::cout;
using std::endl;

// --------------------------------------------------------------------------------------
//  Constructors
// --------------------------------------------------------------------------------------

TestVideoSurface::TestVideoSurface() : TestCuda((ProviderUse_I *)new VideoSurfaceProvider())
    {
    enableTestPerformance(true, thresholdPerformanceFps());
    }

// --------------------------------------------------------------------------------------
// Methodes
// --------------------------------------------------------------------------------------

/**
 * Override
 */
void TestVideoSurface::allTests()
    {
    TEST_ADD(TestCuda::testPerformance); // @suppress("Invalid overload")
    TEST_ADD(TestVideoSurface::testSpecial);
    }

/**
 * si on le met pas probleme de title dans le html (workaround for this, le test en soi n'est pas important
 */
void TestVideoSurface::testSpecial()
    {
    showTitle("Test special ");

    const int MP = Hardware::getMPCount();
    const int CORE_MP = Hardware::getCoreCountMP();

    const bool IS_CHECK_HEURISTIC = false;
    dim3 dg(64, 1, 1);
    dim3 db(1024, 1, 1);
    Grid grid(dg, db, IS_CHECK_HEURISTIC); // power 2

    test(grid);
    }

// ---------------------------------
//  Private
// ---------------------------------

/**
 * static
 */
long TestVideoSurface::thresholdPerformanceFps()
    {
    return 1400; // cbi naif  1800
    }

// --------------------------------------------------------------------------------------
//  End
// --------------------------------------------------------------------------------------
